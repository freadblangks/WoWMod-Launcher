# WoWMod-Launcher
Luncher which enables user to download on web-specified files and folders into his WoW WotLK client. Useful for both projects in development and private servers already opened to players.

Deployment manual: https://model-changing.net/files/file/88-wowmod-launcher/
